import interfaces.*;
import classes.*;
import java.lang.*;
import java.util.*;
import io.*;

public class Start 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
        
		String user, pass, choice;

		System.out.println("Press 1 for User login \n2 for Admin login");
		choice = sc.nextLine();

		System.out.println("Please enter your Username");
		user = sc.nextLine();

		System.out.println("Now enter your Password");
		pass = sc.nextLine();

		switch(choice){
			case "1":
				if(user.equals("Sanuar") && pass.equals("1111"))
				{
					System.out.println("Your login is successful");
				}
				else
				{
					System.out.println("Invalid username or password");
				}
				break;
			case "2":
			 	if(user.equals("Admin") && pass.equals("0000"))
				{
					System.out.println("Your login is successful");
				}
				else
				{
					System.out.println("Invalid username or password");
				}

	}
		System.out.println();
		System.out.println("Welcome to Gym Center Management System. ");
		Gymnasium g = new Gymnasium();

		boolean choice1 = true;

		while(choice1)
		{
			System.out.print("Please follow options mentioned below: \n");
			System.out.println("  1. Member Management");
			System.out.println("  2. Trainer Management");
			System.out.println("  3. Stuff Management");
			System.out.println("  4. Member Attendance and Fee");
			System.out.println("  5. Exit Application\n");
			System.out.print("Please select any of these options: ");

			int first = sc.nextInt();
			System.out.println();

			switch(first)
			        {
			      	    case 1:
			      	        System.out.println("Welcome to Member Management");
			      	        System.out.print("Please follow options given below:\n");
			      	        System.out.println("  1. Create a New Member");
			      	        System.out.println("  2. Remove Existing Member");
			      	        System.out.println("  3. See all Members");
			      	        System.out.println("  4. Go Back\n");
			      	        System.out.print("Please select any of these options: ");

			      	        int second1 = sc.nextInt();
			      	        System.out.println();

			      	        switch(second1)
			      	        {
			      	        	case 1:
			      	        	    System.out.println("You have selected to create a new Member\n");
			      	        	    System.out.println("Please Enter Member Name: ");
			      	        	    String name = sc.next();
			      	        	    System.out.println("Enter Member Phone Number: ");
			      	        	    long num = sc.nextLong();
			      	        	    System.out.println("Enter Member Id:");
			      	        	    long id = sc.nextLong();

    	                            Member m = new Member();
    	                            m.setMemberName(name);
    	                            m.setPhoneNumber(num);
    	                            m.setMemberId(id);
    	                            g.insertMember(m);
    	                            break;

    	                        case 2:
    	                                    
    	                            System.out.println("You have Selected to Remove an Existing Member");
    	                            System.out.println("Enter Member Id: ");
    	                            g.removeMember(g.getMember(sc.nextLong()));
    	                            break;
    	                                    
    	                        case 3:
    	                                    
    	                            System.out.println("You have Selected to See all Members\n");
    	                            g.showAllMember();
    	                            break;

    	                        case 4:
    	                                    
    	                            System.out.println("You have Selected to Go Back");
    	                            break;
    	                                    
    	                        default:
    	                            System.out.println("Invalid Number");
    	                            break;

			      	        }
			      	        break;

			      	    case 2:
			      	        System.out.println("Welcome to Trainer Management");
			      	        System.out.print("Please Follow Options Given Below\n");
			      	        System.out.println("  1. Create a New Trainer");
			      	        System.out.println("  2. Remove Existing Trainer");
			      	        System.out.println("  3. See all Trainer");
			      	        System.out.println("  4. Go Back\n");
			      	        System.out.print("Please select any of these options: ");

			      	        int second2 = sc.nextInt();
			      	        System.out.println();

			      	        switch(second2)
			      	        {
			      	            case 1:
			      	                System.out.println("You have Selected to Create a New Trainer\n");
			      	               	System.out.println("Please Enter Trainer Name: ");
			      	                String name1 = sc.next();
			      	                System.out.println("Enter Trainer Phone Number: ");
			      	       	        long num1 = sc.nextLong();
			      	       	        System.out.println("Enter Trainer Id");
			      	       	        long id1 = sc.nextLong();
			      	       	        System.out.println("Trainer Salary");
			      	       	        double salary = sc.nextDouble();

			      	                Trainer t = new Trainer();
			      	       	        t.setTrainerName(name1);
			      	       	        t.setTrainerPhoneNumber(num1);
			      	       	        t.setTrainerId(id1);
			      	       	        t.setTrainerSalary(salary);
			      	       	        g.insertTrainer(t);
			      	       	        break;

			      	       	    case 2:
			      	       	        System.out.println("You have Selected to Remove an Existing Trainer ");
			              	        System.out.println("Enter Trainer Id: ");
			   	        	        g.removeTrainer(g.getTrainer(sc.nextLong()));
			   	        	        break;

			      	            case 3:
			      	       	        System.out.println("You have Selected to See all Existing Trainer ");
			      	       	        g.showAllTrainer();
			      	       	        break;
			      	       	    case 4:
			      	       	        System.out.println("You have Selected to Go Back ");
			      	       	        break;
			      	       	    default:
			      	       	        System.out.println("Invalid Number");
			                }
			   	            break;

			            case 3:
	  	                    System.out.println("Welcome to Stuff Management");
		                    System.out.print("Please Follow Options Given Below\n");
			      	        System.out.println("  1. Create a New Stuff");
			                System.out.println("  2. Remove Existing Stuff");
			                System.out.println("  3. See all Stuffs");
			      	        System.out.println("  4. Go Back\n");
			      	        System.out.print("Please select any of these options: ");

			      	        int second3 = sc.nextInt();
			                System.out.println();

			      	        switch(second3)
			                {
			      	            case 1: 
			      	      	        System.out.println("You have Selected to Create a New Stuff\n");
		            	            System.out.println("Please Enter Stuff Name: ");
			      	        	    String name2 = sc.next();
			      	                System.out.println("Enter Stuff Phone Number: ");
			      	        	    long num2 = sc.nextLong();
			      	                System.out.println("Enter Stuff Id");
			      	                long id2 = sc.nextLong();
			      	                System.out.println("Stuff Salary");
			      	                double salary2 = sc.nextDouble();

			      	        	    Stuff s = new Stuff();
			      	        	    s.setStuffName(name2);
			      	        	    s.setStuffPhoneNumber(num2);
			      	        	    s.setStuffId(id2);
			      	        	    s.setStuffSalary(salary2);
			      	        	    g.insertStuff(s);
			      	        	    break;

			      	            case 2:
			      	        	    System.out.println("You have Selected to Remoive an Existing Stuff");
			      	        	    System.out.println("Enter Stuff Id: ");

			      	        	    g.removeStuff(g.getStuff(sc.nextLong()));
			      	        	    break;

			      	            case 3:
			      	        	    System.out.println("You have Selected to See all the Stuffs");
			      	        	    g.showAllStuff();
			      	        	    break;

			      	        	case 4:
			      	        	    System.out.println("You have Selected to Go Back");
			      	        	    break;

			      	        	default:
			      	        	    System.out.println("Invalid Number ");
			      	        	    break;   
			      	        }
                            break;

			            case 4:
			      	        System.out.println();
			      	        System.out.println("Please Follow Options Given Below");
			      	        System.out.println("1. You have Selected to See Member Attendance and Fees");
			      	        System.out.println("2. Go Back");
			      	        System.out.print("Please select any of these options: ");			      	                   
			      	                    
			      	        int second4 = sc.nextInt();
			      	                     
			      	        switch(second4)
			      	        {
			      	            case 1:
			      	                System.out.println("Enter Id Number: ");
			      	                long idNum = sc.nextLong();
			      	                System.out.println("Enter Admission Fee: ");
			      	                double fee = sc.nextDouble();
			      	                System.out.println("Monthly Fee: ");
			      	                double mFee = sc.nextDouble();
			      	                System.out.println("How Many Days did You Attend this Month: ");  
			      	                int atd = sc.nextInt();
			      	                System.out.println();

			      	                Attendance at = new Attendance();
			      	                    	
			      	                at.setIdNumber(idNum);
			      	                at.setAdmissionFee(fee);
			      	                at.setMonthlyFee(mFee);
			      	                at.setAttendance(atd);

			      	                at.showDetails();
			      	                break;

			      	           	case 2:
			      	                System.out.println("You have Selected to Go Back");
			      	                break;

			      	            default:
			      	                System.out.println("Error"); 
			      	                break;

			      	        } 
			                break;      

			            case 5:
			      	        System.out.println("You have Selected to Exit the Application");
					        System.out.println("Thank You For Using Our Simple Gym Management System ");				                       
					        choice1 = false;
					        break;
					
				        default:
			                System.out.println("Invalid Number");
			                break;
                    }
		}

	}
}