package interfaces;
import classes.*;
import java.lang.*;

public interface TrainerOperations
{
	void insertTrainer(Trainer t);
	void removeTrainer(Trainer t);
	Trainer getTrainer(long trainerId);
	void showAllTrainer();
}