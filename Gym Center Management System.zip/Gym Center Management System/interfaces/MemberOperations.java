package interfaces;
import classes.*;
import java.lang.*;

public interface MemberOperations
{
	void insertMember(Member m);
	void removeMember(Member m);
	Member getMember(long memberId);
	void showAllMember();
}