package classes;
import java.lang.*;
import interfaces.*;

public class Member implements IdOperations
{
	private String memberName;
	private long phoneNumber;
	private long memberId;
	private Id id[] = new Id[20];

	public void setMemberName(String memberName){ this.memberName=memberName;}
	public void setPhoneNumber(long phoneNumber){ this.phoneNumber=phoneNumber;}
	public void setMemberId(long memberId){ this.memberId=memberId;}

	public String getMemberName(){ return memberName;}
	public long getPhoneNumber(){ return phoneNumber;}
	public long getMemberId(){ return memberId;}

	public void insertId(Id a)
	{
		int flag = 0;
		for(int i =0; i<id.length; i++)
		{
			if(id[i] == null)
			{
				id[i]=a;
				flag=1;
				break;
			}

		}
		if(flag == 1){ System.out.println("Id Inserted");}
		else{ System.out.println("Can Not Insert Id");}
	}

	public void removeId(Id a)
	{
        int flag = 0;
		for(int i = 0; i<id.length; i++)
		{
			if(id[i] == a)
			{
                id[i] = null;
                flag = 1;
                break;
			}
		}
		if(flag == 1){ System.out.println("Member Removed");}
		else{ System.out.println("Can Not Remove Member");}
	}

	public Id getId(long idNumber)
	{
		Id a = null;
		for(int i = 0; i<id.length; i++)
		{
			if(id[i] != null)
			{
				if(id[i].getIdNumber() == idNumber)
				{
					a = id[i];
					break;
				}
			}
		}
		if(a != null)
		{
			System.out.println("Id Found");
		}
		else
		{
			System.out.println("Id Not Found");
		}
		return a;
	}
	
	public void showAllId()
	{
		for(int i=0; i<id.length; i++)
		{
			if(id[i] != null)
			{
				id[i].showDetails();
				System.out.println();
			}
		}
	}

	public void showDetails()
	{
		System.out.println("Member Name: "+memberName);
		System.out.println("Member Phone Number: "+phoneNumber);
		System.out.println("Member Id: "+memberId);
	}
}