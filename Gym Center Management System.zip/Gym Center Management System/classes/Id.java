package classes;
import interfaces.*;
import java.lang.*;

public abstract class Id 
{
    protected long idNumber;
    protected double admissionFee;
    protected double monthlyFee;

    public void setIdNumber(long idNumber){ this.idNumber=idNumber;}
    public void setAdmissionFee(double admissionFee){ this.admissionFee=admissionFee;}
    public void setMonthlyFee(double monthlyFee){ this.monthlyFee = monthlyFee;}

    public long getIdNumber(){ return idNumber;}
    public double getAdmissionFee(){ return admissionFee;}
    public double getMonthlyFee(){ return monthlyFee;}

    public abstract void showInfo();

    public void showDetails()
    {
      System.out.println("Id Number: "+idNumber);
      System.out.println("Admission fee: "+admissionFee);
      System.out.println("Monthly fee: "+monthlyFee);
    }

}