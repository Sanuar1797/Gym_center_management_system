package classes;
import interfaces.*;
import java.lang.*;

public class Stuff 
{
	private long stuffId;
	private String stuffName;
	private double stuffSalary;
    private long stuffPhoneNumber;

    public void setStuffId(long stuffId){ this.stuffId=stuffId;}
    public void setStuffName(String stuffName){ this.stuffName=stuffName;}
    public void setStuffSalary(double stuffSalary){ this.stuffSalary=stuffSalary;}
    public void setStuffPhoneNumber(long stuffPhoneNumber){ this.stuffPhoneNumber=stuffPhoneNumber;}

    public long getStuffId(){ return stuffId;}
    public String getStuffName(){ return stuffName;}
    public double getStuffSalary(){ return stuffSalary;}
    public long getStuffPhoneNumber(){ return stuffPhoneNumber;}

    public void showDetails()
    {
    	System.out.println("Stuff Name: "+stuffName);
    	System.out.println("Stuff Id: "+stuffId);
    	System.out.println("Stuff Phone Number: "+stuffPhoneNumber);
    	System.out.println("Stuff Salary: "+stuffSalary);
    }
    
}