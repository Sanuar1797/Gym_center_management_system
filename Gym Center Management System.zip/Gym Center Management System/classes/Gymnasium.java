package classes;
import interfaces.*;
import java.lang.*;

public class Gymnasium implements MemberOperations, StuffOperations, TrainerOperations
{
    private Member members[] = new Member[1000];
    private Stuff stuffs[] = new Stuff[100];
    private Trainer trainers[] = new Trainer[5];

    public void insertMember(Member m)
    {
    	int flag = 0;
    	for(int i = 0; i<members.length; i++)
    	{
    		if(members[i] == null)
    		{
    			members[i] = m;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Member Inserted");}
    	else {System.out.println("Member Can Not Insert");}
    }

    public void removeMember(Member m)
    {
        int flag = 0;
    	for(int i = 0; i<members.length; i++)
    	{
    		if(members[i] == m)
    		{
    			members[i] = null;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Member Removed ");}
    	else {System.out.println("Member Can Not Remove");}
    }

    public Member getMember(long memberId)
	{
		Member m = null;
		for(int i = 0; i<members.length; i++)
		{
			if(members[i] != null)
			{
				if(members[i].getMemberId() == memberId)
				{
					m = members[i];
					break;
				}
			}
		}
		if(m != null)
		{
			System.out.println("Member Found");
		}
		else
		{
			System.out.println("Member Not Found");
		}
	     return m;
	}
	
	public void showAllMember()
	{
		for(int i = 0; i<members.length; i++)
		{
			if(members[i] != null)
			{
				members[i].showDetails();
				System.out.println();
			}
		}
	}

	public void insertTrainer(Trainer t)
    {
    	int flag = 0;
    	for(int i = 0; i<trainers.length; i++)
    	{
    		if(trainers[i] == null)
    		{
    			trainers[i] = t;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Trainer Inserted");}
    	else {System.out.println("Trainer Can Not Insert");}
    }

    public void removeTrainer(Trainer t)
    {
        int flag = 0;
    	for(int i = 0; i<trainers.length; i++)
    	{
    		if(trainers[i] == t)
    		{
    			trainers[i] = null;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Trainer Removed ");}
    	else {System.out.println("Trainer Can Not Remove");}
    }

    public Trainer getTrainer(long trainerId)
	{
		Trainer t = null;
		for(int i = 0; i<trainers.length; i++)
		{
			if(trainers[i] != null)
			{
				if(trainers[i].getTrainerId() == trainerId)
				{
					t = trainers[i];
					break;
				}
			}
		}
		if(t != null)
		{
			System.out.println("Trainer Found");
		}
		else
		{
			System.out.println("Trainer Not Found");
		}
	     return t;
	}
	
	public void showAllTrainer()
	{
		for(int i = 0; i<trainers.length; i++)
		{
			if(trainers[i] != null)
			{
				trainers[i].showDetails();
				System.out.println();
			}
		}
	}

	public void insertStuff(Stuff s)
    {
    	int flag = 0;
    	for(int i = 0; i<stuffs.length; i++)
    	{
    		if(stuffs[i] == null)
    		{
    			stuffs[i] = s;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Stuff Inserted");}
    	else {System.out.println("Stuff Can Not Inserted");}
    }

    public void removeStuff(Stuff s)
    {
        int flag = 0;
    	for(int i = 0; i<stuffs.length; i++)
    	{
    		if(stuffs[i] == s)
    		{
    			stuffs[i] = null;
    			flag = 1;
    			break;
    		}
    	}
    	if(flag == 1){System.out.println("Stuff Removed ");}
    	else {System.out.println("Stuff Can Not Remove");}
    }

    public Stuff getStuff(long stuffId)
	{
		Stuff s = null;
		for(int i = 0; i<stuffs.length; i++)
		{
			if(stuffs[i] != null)
			{
				if(stuffs[i].getStuffId() == stuffId)
				{
					s = stuffs[i];
					break;
				}
			}
		}
		if(s != null)
		{
			System.out.println("Stuff Found");
		}
		else
		{
			System.out.println("Stuff Not Found");
		}
	     return s;
	}
	
	public void showAllStuff()
	{
		for(int i = 0; i<stuffs.length; i++)
		{
			if(stuffs[i] != null)
			{
				stuffs[i].showDetails();
				System.out.println();
			}
		}
	} 
 
}