package classes;
import interfaces.*;
import java.lang.*;

public class Trainer
{
	private long trainerId;
	private String trainerName;
	private double trainerSalary;
    private long trainerPhoneNumber;

    public void setTrainerId(long trainerId){ this.trainerId=trainerId;}
    public void setTrainerName(String trainerName){ this.trainerName=trainerName;}
    public void setTrainerSalary(double trainerSalary){ this.trainerSalary=trainerSalary;}
    public void setTrainerPhoneNumber(long trainerPhoneNumber){ this.trainerPhoneNumber=trainerPhoneNumber;}

    public long getTrainerId(){ return trainerId;}
    public String getTrainerName(){ return trainerName;}
    public double getTrainerSalary(){ return trainerSalary;}
    public long getTrainerPhoneNumber(){ return trainerPhoneNumber;}

    public void showDetails()
    {
    	System.out.println("Trainer Name: "+trainerName);
    	System.out.println("Trainer Id: "+trainerId);
    	System.out.println("Trainer Phone Number: "+trainerPhoneNumber);
    	System.out.println("Trainer Salary: "+trainerSalary);
    }
}