import java.io.*;

public class CreateFile
{
	public static void main(String args[])
	{
       try
       {
       	  File newFile = new File("D:\\File\\Gym.txt");

       	  if(newFile.createNewFile())
       	  {
       	  	System.out.println("File is created "+newFile.getName());
       	  }
       	  else
       	  {
       	  	System.out.println("The file could not be created ");
       	  }

       	  if(newFile.exists())
       	  {

       	  		System.out.println("File is there ");
       	  }
       	  else
       	  {
       	  	System.out.println("File could not be foound ");
       	  }
       }

       catch(IOException io)
       {
           System.out.println("An error occured and failed to creat the file ");
           io.printStackTrace();
       }
	}
}