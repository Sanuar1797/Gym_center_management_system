import java.io.*;
import java.util.*;

public class ReadFile
{
	public static void main(String args[])
	{
		try
		{
			File file = new File("D:\\File\\Gym.txt");

			Scanner sc = new Scanner(file);

			while(sc.hasNext())
			{
				String line1 = sc.nextLine();
				String line2 = sc.nextLine();
				//String line3 = sc.nextLine();

				System.out.println(line1);
				System.out.println(line2);
				//System.out.println(line3);

				System.out.println("------------");
				System.out.println("File has been read");


			}

			System.out.println(file.getName());
			System.out.println(file.length());
			sc.close();

			//System.out.println(file.delete());
		}

		catch(Exception ex)
		{
			return;
		}
	}
}