import java.io.*;

public class WriteFile
{
	public static void main(String args[])
	{
		try
		{
			FileWriter file = new FileWriter("D:\\File\\Gym.txt");

			file.write("This is a Sample Gym Management System ");

			System.out.println("Written in the new file successfully");

			file.close();
		}
		catch(IOException io)
		{
			System.out.println("An error has occured");
			io.printStackTrace();
		}
	}
}